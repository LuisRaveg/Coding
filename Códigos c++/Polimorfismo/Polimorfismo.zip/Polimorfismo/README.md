# Programación Orientada a Objetos TC1030

## Tarea Excepciones

- Usa tu clase Fracción creada en la **Tarea de sobrecarga de operadores.**
- En el constructor de la clase Fraccion **lanza una excepción** cuando se detecte que el denominador es igual a cero o menor.
- El argumento debe de ser un **string** con un mensaje de cual fue la causa del error. 
- En el método main deberá recibir del teclado (usando cin) los valores de numerado y de denominador.
- Si se detecta una excepción deberá de recuperarse volviendo a pedir el valor para crear la Fracción nuevamente
- No podrá continuar el programa hasta que no sea creada una Fracción correctamente


### Entrega

1. Sube los archivos via GitHubClassroom
